import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-artist',
  templateUrl: './update-artist.component.html',
  styleUrls: ['./update-artist.component.css']
})
export class UpdateArtistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
