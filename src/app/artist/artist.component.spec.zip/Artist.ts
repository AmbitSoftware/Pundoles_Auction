export interface Artist {
    name: String;
    Description: String;
    dateOfBirth: Date;
    dateOfDeath: Date;
}