import { Component, OnInit } from '@angular/core';
import { ArtistService } from './artist.service';
import { Artist } from './Artist';

@Component({
  selector: 'app-artist',
  templateUrl: './artist.component.html',
  styleUrls: ['./artist.component.css']
})
export class ArtistComponent implements OnInit {

  artists: Artist[];
  settings = {
    columns: {

      Actions: //or something
      {
        title:'',
        type:'html',
        valuePrepareFunction:(cell,row)=>{
          return `<a title="Edit" href="#/updateArtist">Update</a>`
        },
        filter:false       
      },
      name: {
        title: 'Name'
      },
      Description: {
        title: 'Description'
      },
      dateOfBirth: {
        title: 'Date Of Birth'
      },
      dateOfDeath: {
        title: 'Date Of Death'
      }

    }
  };
  constructor(private tservice: ArtistService) { }

  ngOnInit() {
    this
      .tservice
      .getartists()
      .subscribe((data: Artist[]) => {
        this.artists = data;
    });
  }
}
