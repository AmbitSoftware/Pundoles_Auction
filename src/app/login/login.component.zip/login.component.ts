import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { LoginService } from './login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: any;
  constructor(private formbulider: FormBuilder, private router : Router, private loginservice : LoginService) { }

  ngOnInit() {
    this.loginForm = this.formbulider.group({
      username:'',
      password: '',
    });
  }
  RedirectTo(){
    const user = this.loginForm.value;
    var loginObject = "grant_type=password&username="+user.username+"&password="+user.password;
    this.loginservice.loginUser(loginObject).subscribe( (response : any) => {
      console.log(response); 
      debugger;
      localStorage.setItem("access_token", JSON.stringify(response.access_token));   
      this.router.navigate(['/users']);
    }, 
    error => {
      debugger;
      console.log(error); 
    });
  }

}
